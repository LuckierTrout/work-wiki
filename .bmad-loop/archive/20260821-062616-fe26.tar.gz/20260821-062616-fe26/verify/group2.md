### DW-25: Nothing states the cross-origin contract an HTTPS page must satisfy to reach `http://127.0.0.1:19828`, so the probe can fail closed forever for reasons the copy cannot explain.
origin: spec-deferred 344c510011f1
location: src/lib/sidecar.ts
source_spec: `spec-1-3-nashsu-icon-rail-and-workbench-chrome.md`
severity: medium
reason: `src/lib/sidecar.ts` documents the fail-closed answer but not the CORS headers the sidecar must return for the deployed origin, Chrome's Private Network Access preflight for a public-to-local request, or Safari's mixed-content handling of a loopback URL. Under any of those the probe answers `down` permanently and Chat shows "Start the local sidecar on 127.0.0.1:19828 to use Chat." to an owner whose sidecar is already running. Epic 1 needs only the up/down signal, and Epic 3 owns the sidecar itself — the response contract belongs with whichever story first ships a real one.
status: open

### DW-72: One stored `embeddingBaseUrl` is handed to whichever embedding provider is active, so an endpoint entered for OpenAI is sent to Google after a switch.
origin: spec-deferred 1ed1cc09bf7d
location: src/lib/embeddings.ts:228-238 (_createEmbeddingModel)
source_spec: `spec-1-9-settings-for-models-and-embeddings.md`
severity: medium
reason: `_createEmbeddingModel` reads `loadConfigSync().embeddingBaseUrl` and applies it to the `openai` and `google` branches alike, with nothing tying the value to the provider it was typed for. This is the endpoint twin of the already-recorded vendor-agnostic `embeddingApiKey`, and it has the same resolution: keying the field per provider is a store-shape decision this story's acceptance does not settle. Nothing breaks today — the pair is usually changed together — but the silent reuse is real.
status: open
decision: 2026-08-21 Clear the base URL on switch — Clear the stored embeddingBaseUrl whenever the embedding provider changes, so an endpoint typed for one vendor is never sent to another; no stored shape change.
decision: 2026-08-20 Clear the base URL on switch — Clear the stored embeddingBaseUrl whenever the embedding provider changes, so an endpoint typed for one vendor is never sent to another; no stored shape change.

### DW-215: Artifact revisions accumulate with no cap or pruning and are walked by the backup scan, which throws rather than degrades at its safety limits.
origin: spec-deferred 5d7e90742d9d
source_spec: `spec-dw-59-per-wiki-artifact-revisions.md`
location: src/lib/wiki-artifact-revisions.ts, src/lib/backups.ts:56-85
severity: medium
reason: Every `writeWikiArtifact` writes a full copy under `tenants/<t>/wikis/<id>/revisions/<file>/` with no retention policy (deliberate — page revisions have none either), and `listWikiArtifactRevisions` stats every revision on each GET with an unbounded `Promise.all`. `src/lib/backups.ts` walks all of `tenants/<t>` against `MAX_BACKUP_FILES = 10_000` / `MAX_BACKUP_BYTES = 2 GB` and throws "Backup exceeds the safety limit" rather than degrading. Page revisions spread across slugs; these pile into one directory per artifact.
status: open
decision: 2026-08-21 Cap revisions and degrade backups — Add a retention cap with pruning in saveWikiArtifactRevision plus a bounded listing, and make the backup walk truncate-with-a-flag at MAX_BACKUP_FILES/MAX_BACKUP_BYTES instead of throwing.
decision: 2026-08-20 Cap revisions and degrade backups — Add a retention cap with pruning in saveWikiArtifactRevision plus a bounded listing, and make the backup walk truncate-with-a-flag at MAX_BACKUP_FILES/MAX_BACKUP_BYTES instead of throwing.

### DW-332: The `drift:<active model>` key is never re-armed, so a corpus that is rebuilt and then drifts again under the same active model is silent for the rest of the process.
origin: spec-deferred 694c7c190212
source_spec: `spec-dw-310-313-embedding-truth-and-warning-attribution.md`
location: src/lib/embeddings.ts (searchByVector, warnedMisconfigurations)
severity: medium
reason: `warnedMisconfigurations` is documented as never clearing, on the argument that "a restart (or a new isolate) already fixes" the case. That holds for the three env/binding misconfigurations it was written for, but not for drift: drift is fixed by REBUILDING THE CORPUS, which happens in the same process. `searchByVector` already holds the counter-signal that proves the drift is over — `kept.length > 0` — and could delete the key there. The intent said only "bring it under the same throttle", and the module's recorded trade-off argues the other way, so whether drift should be the one identity that re-arms is a decision neither contains.
status: open
decision: 2026-08-21 Re-arm drift only — Delete only the drift:<active model> key from warnedMisconfigurations on a successful read where kept.length > 0, leaving every other member of the Never clause intact, and cover rebuild-then-re-drift in the embeddings warning suite.
decision: 2026-08-20 Re-arm drift only — Delete only the drift:<active model> key from warnedMisconfigurations on a successful read where kept.length > 0, leaving every other member of the Never clause intact, and cover rebuild-then-re-drift in the embeddings warning suite.

### DW-352: IDENTIFIER_ALLOWLIST's /yopedia-[a-z-]+/g swallows display prose, the way the workwiki family did before it was anchored.
origin: spec-deferred 41f20a262d72
source_spec: `spec-dw-236-244-brand-scan-coverage.md`
location: src/lib/__tests__/brand-copy.test.ts:52
severity: medium
reason: strayYopedia("the yopedia-first workflow") returns no match, so that prose would pass the scan. The workwiki side guards the identical case with its anchored alternation and a "the workwiki-first approach" slip case. The pattern is pre-existing and narrowing it needs evidence about which real Cloudflare resource names depend on it, so the new yopedia case table pins today's behaviour rather than changing it.
status: open

### DW-370: `detectEnvProvider()` and the embedding provider detection still select `ollama` from the mere presence of `OLLAMA_BASE_URL`, including a value `getOllamaBaseUrl` now refuses.
origin: spec-deferred 9a66b32844ef
source_spec: `spec-dw-71-326-272-settings-config-resolution-hardening.md`
location: src/lib/config.ts:739
severity: medium
reason: src/lib/config.ts:739-742 and src/lib/embeddings.ts:217 branch on the variable's presence, not on its usability. After DW-326 a typo'd `OLLAMA_BASE_URL=localhost:11434` both SELECTS the ollama provider and resolves to no endpoint, so generation and embed silently go to the SDK's own localhost default instead of failing against the address the owner typed. Pre-existing detection logic; the fall-through this bundle chose over a refusal is what makes the outcome silent. Closing it means either detecting through the validated accessor or writing down why detection deliberately answers a wider question.
status: open

### DW-378: `readWikiPage` answers `null` for a page that is UNREADABLE as well as one that is absent, so a storage blip on the page write's merge-base read is reported as `404 page not found`.
origin: spec-deferred e2c2f3bbd280
source_spec: `spec-dw-193-194-195-200-write-precondition-and-version-freshness.md`
location: src/lib/wiki.ts:409, src/app/api/wiki/[slug]/route.ts:161
severity: medium
reason: `src/lib/wiki.ts:409-419` warns and returns `null` for every non-ENOENT read failure, and `PUT /api/wiki/[slug]` turns that `null` into `page not found: <slug>` before the precondition is ever consulted. This bundle made exactly the opposite call one layer over: when `writeWikiArtifact` is given an `expectedVersion`, a failed pre-write read rethrows rather than being read as "absent", because "absent" is answered as a conflict and a blip is not one. The page path keeps the older behaviour, so the same transient failure is a 404 on one surface and a 500 on the other. Pre-existing — the swallow predates the precondition and this change only added the `fresh` option beside it — and closing it means changing `readWikiPage`'s null contract, which ~40 callers depend on.
status: open

### DW-387: `/settings` now states three different sentences for one deployment state, none of them owned by `READ_ONLY_REFUSAL` and none pinned by the parity suite.
origin: spec-deferred cba66956e0ae
source_spec: `spec-dw-264-265-294-299-300-314-read-only-doors-and-affordances.md`
location: src/app/settings/page.tsx:147; src/app/api/settings/route.ts:130; src/app/api/settings/rebuild-embeddings/route.ts
severity: medium
reason: The banner every refused control now points at reads "Read-only mode — This deployment has explicitly disabled settings changes."; `PUT /api/settings` answers "Settings are read-only in this deployment."; `POST /api/settings/rebuild-embeddings` answers a third wording. Only the banner is on screen, so the owner reads one sentence before pressing and another if anything reaches the route.
status: open

