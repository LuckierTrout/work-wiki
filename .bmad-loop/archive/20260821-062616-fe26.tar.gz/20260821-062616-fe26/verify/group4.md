### DW-40: A read under `raw/` inherits `resolveRoot`'s fallback to the SHARED flat root, so an owner whose raw silo is empty reads the legacy tree's bytes.
origin: spec-deferred 8926f334b742
location: src/lib/workbench-files.ts (resolveWorkbenchFile, resolveRoot)
source_spec: `spec-1-5-view-first-preview-with-gfm-and-wikilinks.md`
severity: medium
reason: `resolveWorkbenchFile` gates only `root === "wiki"`; `raw/…` goes straight to `resolveRoot(silo, flat)`, which falls back to the shared `RAW_DIR` when the caller's silo lists empty. That is not a deviation — the intent ties the file gate to what `listWorkbenchFilePaths` would emit, and the listing walks `raw/` with `allowEveryLeaf` through the same `resolveRoot` — so read and listing agree exactly, as required. What changed is the stakes: Story 1.4 disclosed those FILENAMES, and this story serves their contents. Narrowing it here is not available: the intent requires `resolveRoot` to have "exactly one definition", and a read gate narrower than the listing would show rows that refuse to open (the sibling entry below). The real fix is retiring the flat root, or giving `raw/` a per-owner gate — both belong with whichever story completes the silo migration, since `src/lib/silo.ts` already calls the flat tree transitional.
status: open

### DW-131: The graph page's canvas accessibility fallback points readers at `/wiki`, which is a retired 404.
origin: spec-deferred 0160c928098e
source_spec: `spec-retire-dead-machinery-round-2.md`
location: src/app/wiki/graph/page.tsx:161
severity: medium
reason: `src/app/wiki/graph/page.tsx:161` sets `aria-label="Wiki page relationship graph. Visit the wiki index for a text-based list of all pages."` and the canvas fallback text (`:164`) repeats it, but `/wiki` is listed in `RETIRED_SURFACES` (`src/lib/retired.ts:23`) and 404s. Deleting `HomeGraph.tsx` in this pass made this the only remaining graph canvas, so it is now the sole accessibility escape hatch for the visualization and it leads nowhere. The file was not touched by this pass and fixing it means choosing a live replacement target, which is a product call.
status: open
decision: 2026-08-19 Point at the Workbench Knowledge tree — Retarget the graph canvas's aria-label and fallback text at the Workbench's Knowledge tree (the live text-based list of the active Wiki's pages), updating the copy to name that surface and linking to it, and pin the new target so it cannot rot into another retired route.

### DW-259: Three of the six converted client components -- RecentIngests, ActionInbox and BulkDocumentImport -- still have no rendered-anchor coverage, so reverting any of their hrefForSlug call sites to slugPat
origin: spec-deferred 8332b2aa4a3f
source_spec: `spec-dw-86-110-118-dom-tests-polling-and-shell.md`
location: src/components/RecentIngests.tsx:487
severity: medium
reason: DW-86's verbatim reason names "the six converted use client components"; the bundle intent's prose named only four (ArticleView, VaultExplorer, ChatWorkspace, KnowledgeStudio) and this story covered those four. `src/components/RecentIngests.tsx:487,568`, `src/components/ActionInbox.tsx:387` and `src/components/BulkDocumentImport.tsx:532` call `hrefForSlug(...)` from the same conversion, and no `*.test.ts`/`*.test.tsx` under `src/` references any of the three. The harness they would need now exists, so this is a remaining gap rather than a constraint.
status: open

### DW-341: The eight-member `fix` list is hand-copied in two documents with nothing pinning either to `MaintainFixType`.
origin: spec-deferred 52bccbf1a637
source_spec: `spec-dw-127-309-doc-drift-corrections.md`
location: src/lib/maintenance.ts:11
severity: medium
reason: src/lib/maintenance.ts's module header and workers/task-consumer/README.md:47-49 both re-list the union by hand. `MaintainFixType` (src/lib/tasks.ts:164-172) appears in no test, so adding a ninth member re-stales both silently -- exactly the mechanism DW-127 reported. DW-130 got a pin in this pass (mcp-annotations.test.ts); this list did not, because the intent did not ask for one.
status: open

### DW-358: Quoted-printable transfer encoding is unaccounted for in the raw-size cap, which is derived from base64 expansion alone.
origin: spec-deferred 18e6b2bf1947
source_spec: `spec-dw-104-247-248-email-worker-caps-and-accounting.md`
location: workers/email-ingest/index.ts
severity: medium
reason: Many clients send text/* attachments and non-ASCII bodies as quoted-printable, which expands up to roughly 3x for byte-dense content — far beyond base64's 4/3. A large .csv or .txt attachment can therefore still be refused below the advertised per-document ceiling, for the same reason DW-104 described for base64.
status: open
decision: 2026-08-21 Widen for worst-case encoding — Derive MAX_RAW_EMAIL_BYTES from the worst-case transfer encoding (a quoted-printable expansion factor rather than base64's ~1.37), re-pin the parity test, and record the new derivation beside the constant.
decision: 2026-08-20 Widen for worst-case encoding — Derive MAX_RAW_EMAIL_BYTES from the worst-case transfer encoding (a quoted-printable expansion factor rather than base64's ~1.37), re-pin the parity test, and record the new derivation beside the constant.

### DW-373: Opening the in-shell Settings surface still unmounts the whole mode canvas, so the Wiki subtree DW-26 keeps mounted across mode switches is destroyed — dialog, typed name and error — whenever Settings
origin: spec-deferred 125b109b6d09
source_spec: `spec-dw-26-62-283-320-workbench-client-state-and-nav.md`
location: src/components/workbench/Workbench.tsx (settingsOpen canvas swap)
severity: medium
reason: `Workbench.tsx` renders `settingsOpen ? <SettingsCanvas …/> : <ModeCanvas …>{children}</ModeCanvas>`, so `children` (`WikiWorkbench`) leaves the tree when the rail's Settings control — or, since this change, `g s` — opens the surface. Pre-existing: the rail control has behaved this way since Story 1.9, and DW-26 names `ModeCanvas` and mode switching only. Closing it means deciding how `SettingsCanvas` keeps owning discard-on-leave for its own draft while no longer being the thing that unmounts the canvas beside it.
status: open

### DW-380: A fresh read still falls back from a FAILED silo read to the flat copy, so a version can describe bytes at a path the write will not target.
origin: spec-deferred 60eded0bf0fa
source_spec: `spec-dw-193-194-195-200-write-precondition-and-version-freshness.md`
location: src/lib/wiki.ts:389
severity: medium
reason: `src/lib/wiki.ts:389-401` warns on a non-ENOENT silo failure and falls through to `wikiRelPath(...)`, which is the legacy flat file. `fresh` bypasses `pageCache` but not that fallback, so a transient silo failure on a precondition-bearing read hands the editor the version of the flat copy while `writeWikiPageWithSideEffects` resolves the tenant path — a precondition computed over one file and compared against another. Pre-existing: the fallback predates the version entirely and exists so a not-yet-migrated page still reads. Closing it means letting a precondition-bearing read refuse rather than widen, which needs the same null-contract change the entry above names.
status: open

### DW-390: Deleting the reconciliation-thread writer took the last programmatic caller of the whole talk thread API with it.
origin: spec-deferred 83dd95b177cf
source_spec: `spec-dw-121-230-269-270-authz-realm-parity-and-read-gates.md`
location: src/lib/talk.ts, src/lib/browse.ts:184
severity: medium
reason: `listThreads`, `createThread`, `getThread`, `addComment`, `resolveThread` and `hasOpenThread` now have no non-test callers; only `deleteDiscussions` (lifecycle.ts), `getDiscussRelPrefix` (discuss-stats-index.ts, contributors.ts) and `getDiscussionStatsForSlugs` (browse.ts) are still read, and the talk HTTP surfaces that drove the rest are retired. A knock-on: `browse.ts:184` still renders a per-page discussion count that nothing can increase any more, and pre-existing reconciliation threads stay on disk feeding it. Retiring that surface — and the discuss-stats/contributor indexes hanging off it — is wider than DW-230 asked, and the spec's Never list forbids touching talk.ts's remaining readers, so it is recorded rather than resolved. The retirement banner in talk.ts says the same thing so the dead surface is not mistaken for live API.
status: open
decision: 2026-08-21 Retire the dead writers only — Delete listThreads, createThread, getThread, addComment, resolveThread and hasOpenThread from src/lib/talk.ts along with their now-orphaned tests, leaving deleteDiscussions, getDiscussRelPrefix and getDiscussionStatsForSlugs (and therefore browse's count and the discuss-stats/contributor indexes) exactly as they are.

