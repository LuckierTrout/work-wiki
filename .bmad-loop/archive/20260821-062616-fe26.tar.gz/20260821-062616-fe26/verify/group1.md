### DW-17: Wiki artifacts sit at `tenants/<t>/wikis/<id>/`, not at the project root beside `wiki/` and `raw/sources/` as FR-76's file contract describes.
origin: spec-deferred b01b1e432d01
location: src/lib/wikis.ts
source_spec: `spec-1-2-create-a-wiki-from-a-scenario-template.md`
severity: medium
reason: The location was chosen so `reconcileSilos()` (`src/lib/silo.ts:230-265`) cannot delete the seeded files as unindexed orphans, and Story 1.2 does not partition Pages or Sources per Wiki. The consequence is that `/api/v1/projects` (Epic 8, FR-76) has no `path` to report and `files?root=all` cannot yet return `purpose.md`, `schema.md`, `wiki/` and `raw/sources/` from one root. Reopening this requires the per-Wiki Page partitioning that Story 1.4's "the trees show that Wiki's files" implies.
status: open

### DW-69: One `embeddingApiKey` is shared by both keyed embedding vendors, so switching provider silently reuses the other vendor's key.
origin: spec-deferred bddb90da84c0
location: src/lib/embeddings.ts:139, src/lib/config.ts (getWorkbenchSettings)
source_spec: `spec-1-9-settings-for-models-and-embeddings.md`
severity: medium
reason: `embeddingApiKeyFor` reads the same stored value for `openai` and `google`, and `settingsSaveBody` omits an untouched secret — so an owner who stored an OpenAI key and then picks Google sends that key to Google while the hint still reads "A key is stored." Keying the field per provider (or labelling which vendor the stored key belongs to) is a store-shape decision this story's acceptance does not settle; the vector gate's env leg was made provider-aware in this pass, but the STORED key deliberately stayed vendor-agnostic so a provider changed in the draft can still answer the gate before it is saved.
status: open
decision: 2026-08-21 Clear the key on switch — Drop the stored embedding key and its has* flag whenever the embedding provider changes, so a switch never reuses another vendor's secret; no stored shape change, and the owner re-enters the key for the new vendor.
decision: 2026-08-20 Clear the key on switch — Drop the stored embedding key and its has* flag whenever the embedding provider changes, so a switch never reuses another vendor's secret; no stored shape change, and the owner re-enters the key for the new vendor.

### DW-211: DW-49's raw-source half is untouched — no writer under `tenants/<t>/raw/` exists yet, so it needs re-checking when Epic 2 Ingest lands one.
origin: spec-deferred 376f1759e471
source_spec: `spec-dw-49-artifact-seed-data-version-bump.md`
location: src/lib/wikis.ts, src/lib/lifecycle.ts
severity: medium
reason: DW-49 names three classes of bypassing writer: template seeding, raw source files, and "any later writer that lands bytes the Files tab renders". Only the first is closed here. A grep of `src/lib` finds no writer under `tenants/<t>/raw/` today, so there is nothing to bump; the guard test in `workbench-data-version.test.ts` will fail the moment a fourth bump site appears, which is the intended tripwire.
status: open

### DW-325: `workspace-purpose-settings.test.tsx` "adopts a recheck that answers no wiki at all" is flaky under full-suite load and can red an unrelated CI run.
origin: spec-deferred 09cd0fe96308
source_spec: `spec-dw-141-workspace-guidance-request-caching.md`
location: src/components/__tests__/workspace-purpose-settings.test.tsx:837
severity: medium
reason: Observed failing once during full-suite verification for this story (the badge still read "not configured" when the 1s `waitFor` expired), then passing on re-run and passing 42/42 in isolation. It is entirely fetchMock-driven, touches nothing in this change, and predates it (introduced with DW-136/142/301). It races the mount fetch against the `returnToTab()` recheck.
status: open

### DW-348: The two untrusted lint-fix doors accept an unvalidated `type` even though `AUTO_FIXABLE_CHECK_TYPES` now exists as a tuple to validate against.
origin: spec-deferred ac2df2d3e945
source_spec: `spec-dw-229-246-hand-copied-list-parity.md`
location: src/app/api/lint/fix/route.ts:54
severity: medium
reason: `src/app/api/lint/fix/route.ts:54-56` destructures `type` off a raw `await req.json()` with no schema at all, and `src/lib/mcp-http.ts:490` declares it as free-form `str(...)`. `src/mcp.ts:2465` does validate, but against `z.enum(ALL_CHECK_TYPES)` rather than the fixable subset. The `ownEntry` guard added by this story is currently the only defense; `z.enum(AUTO_FIXABLE_CHECK_TYPES)` at the door would make it a second line rather than the sole one.
status: open

### DW-368: The Extraction provider picker on the same flat /settings page also offers Custom and renders no base-URL or API-key field, so it stores a provider the runtime refuses to construct with no on-page poi
origin: spec-deferred ab8661d17322
source_spec: `spec-dw-61-327-329-legacy-settings-surface-parity.md`
location: src/components/StructuredKnowledgeSettings.tsx:84-99
severity: medium
reason: StructuredKnowledgeSettings.tsx populates its select from the same PROVIDER_INFO list that carries `custom`; the route accepts structuredKnowledgeProvider: "custom" and config.ts resolves it through getConfiguredModel, which throws "The Custom provider needs a base URL. Set it in Settings -> LLM Models." (src/lib/llm.ts:395-408) - the twin of the primary path's throw at :285-301 that DW-61 closed. Pre-existing: the DW-61 ledger entry and this bundle's intent both scope the fix to ProviderForm's picker, so the extraction picker was never in scope. There is no test file for StructuredKnowledgeSettings at all.
status: open

### DW-377: Retry attempts are counted per qualifying poll rather than per settled re-render, so a nudge or visibility burst — or a merely slow refresh — can spend the whole budget before any new baseline has had
origin: spec-deferred eb490a039820
source_spec: `spec-dw-48-data-version-refresh-retry.md`
location: src/components/workbench/DataVersionWatcher.tsx (run), src/lib/workbench-data-version.ts (DATA_VERSION_REFRESH_ATTEMPTS)
severity: medium
reason: `run()` has three triggers: the `DATA_VERSION_POLL_MS` interval, `visibilitychange` -> visible, and the `requestDataVersionCheck()` save nudge (`PreviewColumn.tsx`). Every qualifying poll from any of them spends an attempt, so three alt-tabs or three saves that all still answer the same version drive `attempts` from 0 to `DATA_VERSION_REFRESH_ATTEMPTS` in milliseconds and re-strand that version — the DW-48 symptom, now probabilistic rather than certain. The same shape covers an in-flight `router.refresh()` still rendering when the next tick fires: a merely slow re-render reads as "did not catch up" and burns an attempt. A wall-clock window (which DW-48's own wording offered as an alternative to a count) or an in-flight guard would close it; both are refresh-policy decisions beyond the bounded-count reading this story implemented, and the count reading is strictly better than the single-shot stamp it replaced in every case.
status: open

### DW-386: Three surfaces now compose a write in front of a door this change taught to answer 403, with no read-only mirror — the DW-264/DW-265 shape, one bundle later.
origin: spec-deferred 56c9d9c9eb3d
source_spec: `spec-dw-264-265-294-299-300-314-read-only-doors-and-affordances.md`
location: src/components/NamesTermsSettings.tsx; src/components/EmailIngestSettings.tsx; src/components/KnowledgeStudio.tsx
severity: medium
reason: `NamesTermsSettings` and `EmailIngestSettings` render immediately below the `/settings` form that now refuses per control, and `KnowledgeStudio` posts to `/api/research`; all three submit and meet the new 403 afterwards. `READ_ONLY_REFUSAL.namesTerms` and `.emailSettings` consequently have no client counterpart and no parity-test entry.
status: open

