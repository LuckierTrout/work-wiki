### DW-58: FR-34's other half is still unbuilt — `purpose.md` is editable from no surface, and the narrow allowlist now pins that shut.
origin: spec-deferred d9e12a049e09
location: src/lib/wiki-scenarios.ts (EDITABLE_ARTIFACT_FILES)
source_spec: `spec-1-8-edit-schema.md`
severity: medium
reason: PRD FR-34 reads "Christian can view/edit purpose and Schema from Settings or Wiki tree", and the UX run names both files. This story's acceptance covers Schema alone, so the exclusion is correct here — but it is now an asserted invariant (`expect(EDITABLE_ARTIFACT_FILES).not.toContain( "purpose.md")`), so a later story must edit a test to open it. Opening it also needs an answer to what `purpose.md` must contain to be valid (the Schema's `hasPageConventions` has no analogue) and to how it reconciles with the tenant-global workspace profile (DW-14, DW-21), which is why it was not simply widened here.
status: open
decision: 2026-08-16 Wait for DW-14

### DW-158: Neither `lint-checks.ts` detector has any test that it resolves the ACTIVE Wiki's Schema — a mutation pinning both to the repo-root file passes the entire suite.
origin: spec-deferred 517d89b179e4
source_spec: `spec-dw-19-single-owner-resolution-invariant.md`
location: src/lib/lint-checks.ts:414 and src/lib/lint-checks.ts:570
severity: medium
reason: `checkContradictions()` and `checkMissingConceptPages()` call the no-argument `loadPageConventions()`. The only lint-side conventions test, `src/lib/__tests__/lint.test.ts:670`, writes a bare `SCHEMA.md` into its tmpdir and never sets `NEXT_PUBLIC_OWNER_HANDLE` or calls `createWiki`, so it exercises only the repo-root fallback branch. Replacing both detector calls with `loadPageConventions(`${process.cwd()}/SCHEMA.md`)` — lint permanently ignoring the active Wiki's seeded Schema — leaves lint.test.ts (73), wiki-schema-source.test.ts and cli.test.ts (83) all green, 170 tests passing. Pre-existing: this is Wiki-vs-root precedence (Story 1.2 / AD-10), not DW-19 tenancy, and the gap predates this change. DW-19's own pins are at the loader plus the two call sites that carry a principal; the lint detectors carry none, so there is no non-owner caller to pin them with.
status: open

### DW-276: A mismatched deployment still EMBEDS under the substituted default; this bundle ended the silence, not the substitution.
origin: spec-deferred 5155e62ce7df
source_spec: `spec-dw-220-221-224-226-227-embedding-resolution.md`
location: src/lib/embeddings.ts:hasEmbeddingSupport with src/lib/ingest.ts:989
severity: medium
reason: DW-224's ledger coordinates are `hasEmbeddingSupport` with `src/lib/ingest.ts:989`, and neither file changed. Under the intent's reading ("stops embedding under the substituted default WITHOUT A WORD") the fix is the warning, and the spec's Never list pins that reading because `src/lib/workbench-settings.ts` and `src/lib/config.ts` both record that Story 2.9 (embed after ingest) and Story 3.4 (search merge) own teaching `hasEmbeddingSupport()` the vector gate. So the harm the ledger measured — a corpus quietly embedded with a model the owner did not choose — is now diagnosable but not prevented, and the tightened predicate moves two more inputs (a bare `@cf/`, a `@cf/` vision id) from "fails at ai.run()" into "substitutes the default". Closing it means refusing to embed on a mismatch, which belongs to those stories.
status: open

### DW-343: `MAINTAIN_FIX_TYPES` has no omission pin and the task-consumer README restates the same `lintType` list in unpinned prose.
origin: spec-deferred 7dfb6b825471
source_spec: `spec-dw-132-249-prose-inventory-parity.md`
location: src/lib/tasks.ts:213
severity: medium
reason: `src/lib/tasks.ts:213` builds `new Set<MaintainFixType>([...])`, which rejects extra members but not omitted ones — the exact half `AssertNever` was added to cover for `TASK_KINDS` one screen above. A ninth fix type wired into `src/lib/maintenance.ts` but forgotten here makes `parseTask` return null at :440, so the enqueued task is treated as poison and goes to the DLQ, with `tsc` silent. `workers/task-consumer/README.md:48-50` restates the eight fix types in prose and nothing reads it — a seventh inventory of the same shape as the six this pass pinned.
status: open

### DW-361: A full-size document and a maximal email body cannot both fit under the derived raw cap, because the 64 KiB envelope allowance is far smaller than MAX_EMAIL_CONTENT_CHARS.
origin: spec-deferred 29968aee1ee7
source_spec: `spec-dw-104-247-248-email-worker-caps-and-accounting.md`
location: workers/email-ingest/index.ts:59
severity: medium
reason: `MAX_RAW_EMAIL_BYTES` leaves 65,533 bytes of slack above the 14,348,938-byte wire size of a base64-encoded `MAX_DOCUMENT_SIZE` document, while the Worker's own `MAX_EMAIL_CONTENT_CHARS` is 100,000 and the body is truncated only *after* the `rawSize` gate. An email carrying a 10 MB attachment plus a body anywhere near the accepted length is refused with a size bounce although every individual limit is respected. Not a regression -- the old 10 MB cap refused that message too -- and the constant's comment now says so, but no test covers the interaction of the two caps.
status: open

### DW-374: Only `TimeoutError`/`AbortError` are treated as unconfirmed, so a dropped connection or a 502/504 is reported as a known failure — with transport vocabulary — and no refresh runs.
origin: spec-deferred e6705ae0513e
source_spec: `spec-dw-26-62-283-320-workbench-client-state-and-nav.md`
location: src/lib/workbench-request.ts (writeFailure)
severity: medium
reason: `writeFailure` returns `unconfirmed: true` for the two abort names and otherwise prefers `cause.message`. A mid-write network drop arrives as `TypeError: Failed to fetch` (Safari: `Load failed`) and a gateway timeout as `send`'s `Request failed (504)`; in both the server may have applied the write, so the owner is told it failed over something unknown, and the screen is not reconciled. `Failed to fetch` also reaches the owner verbatim, which `workbench-settings.ts` already calls transport vocabulary no copy table contains. Pre-existing shape: `failureMessage` classified these the same way before this change.
status: open

### DW-382: `deleteWiki` removes a Wiki's `purpose.md` and `schema.md` outright and moves no `dataVersion`, so a Preview open on those artifacts in a second client keeps rendering bytes whose Wiki is gone.
origin: spec-deferred e419c472892c
source_spec: `spec-dw-209-289-wiki-rename-refresh-and-sweep-cap.md`
location: src/lib/wikis.ts (deleteWiki)
severity: medium
reason: DW-209 established the rule this change generalises: a registry operation that also moves bytes a Preview renders must bump, because a non-current Wiki's operations change no `currentWikiId` and the Workbench's selection-reset effect never fires. `deleteWiki` (src/lib/wikis.ts) meets that description exactly — it deletes the artifact directory — and still carries no tail. `WikiSwitcher.tsx` calls `router.refresh()` itself, which covers the client that performed the delete but not any other open client. Pre-existing; surfaced by generalising the rule, not caused by it.
status: open

### DW-392: Revert is still offered to signed-out viewers on every page the realm does not restrict.
origin: spec-deferred 5acd94afc307
source_spec: `spec-dw-121-230-269-270-authz-realm-parity-and-read-gates.md`
location: src/components/RevisionHistory.tsx
severity: medium
reason: `canRevert` in `src/components/RevisionHistory.tsx` carries a realm term and a site-owner term but no `isSignedIn` term, so an anonymous viewer of a public artifact or an agent-scoped page is still shown Revert and its irreversible-sounding confirm in front of a write the middleware 401s. This predates DW-269 (the control was ungated for everyone), and the recorded intent asked only for "the same realm term the Delete gate got", with the spec's Never list forbidding an ownership term — so the signed-in half was deliberately left alone. `ArticleActions` reads `isSignedIn` for exactly this purpose one component over.
status: open

