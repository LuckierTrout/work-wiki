### DW-68: Storing an embedding key through the new surface flips `hasEmbeddingSupport()` on for the existing ingest caller even with vector search switched off.
origin: spec-deferred 050a745f1202
location: src/lib/embeddings.ts:139 (embeddingApiKeyFor), src/lib/ingest.ts:989
source_spec: `spec-1-9-settings-for-models-and-embeddings.md`
severity: medium
reason: `embeddingApiKeyFor` now falls back to `loadConfigSync().embeddingApiKey` (which the spec's Execution list requires, or the three stored vector values would have no reader at all). `hasEmbeddingSupport()` → `getEmbeddingModelName()` → `resolveEmbeddingProvider()` → `embeddingApiKeyFor()`, so an owner who pastes a key into Settings → Embeddings and leaves the switch off — the story's headline default — turns `ingest.ts:989` from off to on. Nothing fails: `embeddings.test.ts` drives that path from env vars, which are unchanged. The epic assigns "embed after ingest only when vector is on" to Story 2.9 and the spec's Never list forbids gating the callers here, so closing it is that story's work.
status: open

### DW-196: The kernel page writer stays unguarded, so the ~18 non-HTTP callers of `writeWikiPageWithSideEffects` — including the ingest and agent writers DW-38 names as the reason the guard is needed — still clo
origin: spec-deferred cd37d8d20782
source_spec: `spec-dw-38-write-preconditions-and-conflict-surface.md`
location: src/lib/lifecycle.ts:731
severity: medium
reason: The guard sits at the HTTP boundary, which is what the intent's operative clause asks for ("enforce `If-Match` on the three routes"), but every DW entry's `location` field also names a kernel writer (`src/lib/lifecycle.ts`, `writeWikiArtifact`, `saveConfig`). `writeWikiPageWithSideEffects` is called unconditionally from `src/mcp.ts`, `src/cli.ts`, `src/lib/agents.ts`, `src/lib/lint-fix.ts`, `src/lib/query.ts`, `src/lib/search.ts`, `src/lib/memory-proposals.ts`, `src/lib/document-sources.ts`, `src/lib/patch-metadata.ts`, `src/app/api/wiki/route.ts` and the revisions route. DW-38's own justification for doing the work now is "Epic 2 gives the same pages a second writer" — and that writer is an ingest path that never travels the guarded route.
status: open
decision: 2026-08-19 Decide with the Epic 2 ingest writer

### DW-323: A manual page merge gets neither Workspace Purpose nor Names & Terms guidance, while an ingest-time reconcile of the same two bodies gets both.
origin: spec-deferred 0fb017929a75
source_spec: `spec-dw-141-workspace-guidance-request-caching.md`
location: src/lib/merge.ts:204
severity: medium
reason: `src/lib/merge.ts:204` calls `reconcilePage(into.body, from.body)` with no `owner`, so the guidance branch at ingest.ts:1168 is skipped entirely. The reconcile prompt is the same prompt in both cases, so the merged prose is held to a different standard depending on which door it came through. This change touched that signature (adding the cache parameter) without closing the asymmetry, which is out of DW-141's scope but worth a decision.
status: open
decision: 2026-08-21 Guide the merge door — Resolve the accountable owner from into.frontmatter.owner (falling back to the acting principal) and pass it plus a fresh createWorkspaceGuidanceCache() into reconcilePage from merge.ts, with a test pinning which owner's guidance a cross-owner merge uses.
decision: 2026-08-20 Guide the merge door — Resolve the accountable owner from into.frontmatter.owner (falling back to the acting principal) and pass it plus a fresh createWorkspaceGuidanceCache() into reconcilePage from merge.ts, with a test pinning which owner's guidance a cross-owner merge uses.

### DW-347: Bulk import's `accept` advertises 21 MIME types its validator never consults, so a file the picker admits by content type alone is still refused client-side.
origin: spec-deferred 4e813d060c28
source_spec: `spec-dw-229-246-hand-copied-list-parity.md`
location: src/lib/bulk-document-import.ts:80
severity: medium
reason: `validationError` (`src/lib/bulk-document-import.ts`) branches only on `documentExtension(file.name)` and ignores `file.type` entirely, while `ACCEPTED_DOCUMENT_ATTRIBUTE` now derives from extensions AND `SUPPORTED_DOCUMENT_MIME_TYPES`. An extension-less file carrying `application/pdf` therefore passes the picker and is rejected by the manifest, though `detectDocumentFormat` at `/api/ingest/document` accepts it on the MIME arm. This is the residual half of DW-246's class (client narrower than server); the intent named the list, not the MIME arm, so it is out of this story's scope.
status: open

### DW-364: The Worker's two misconfiguration early-returns -- missing service token and missing site URL -- produce sender-visible replies that no test observes.
origin: spec-deferred def3eb49a02e
source_spec: `spec-dw-250-251-252-254-email-ingest-test-coverage.md`
location: workers/email-ingest/index.ts:255-263
severity: medium
reason: `workers/email-ingest/index.ts:255-263` replies "the ingest service is not configured" and returns without forwarding when `YOPEDIA_SERVICE_TOKEN` is absent; :326 throws `YOPEDIA_SITE_URL is missing`, caught by the surrounding try/catch into the "could not queue this email" reply. Neither branch is exercised anywhere, so deleting either -- and forwarding an unauthenticated request, or one to a relative URL -- fails nothing. The new `forwardedRequest(siteUrl)` helper already parameterises the site, so the second is one fixture away.
status: open

### DW-376: `SettingsCanvas.save` and `PreviewColumn` carry their own deadlines and still report a blown one as a flat failure, which is the claim DW-283 says the client cannot make.
origin: spec-deferred 5d49180cca3b
source_spec: `spec-dw-26-62-283-320-workbench-client-state-and-nav.md`
location: src/components/workbench/SettingsCanvas.tsx (save), src/components/workbench/PreviewColumn.tsx
severity: medium
reason: Both arm their own `AbortSignal` rather than using `send` (each needs the controller), so neither reaches `writeFailure`. `SettingsCanvas.save` resolves an abort to `SETTINGS_SAVE_FAILED_COPY` ("Settings couldn’t be saved.") over a PUT the server may have applied — on the surface this change just made keyboard-reachable through `g s`. Out of DW-283's stated scope, which names `workbench-request.ts` and the wiki writes.
status: open

### DW-385: The research, Names & Terms and email-ingest stores carry no `assertWritable`, so a CLI, MCP or agent-runtime caller still writes them on a read-only deployment.
origin: spec-deferred 192b376cbc62
source_spec: `spec-dw-264-265-294-299-300-314-read-only-doors-and-affordances.md`
location: src/lib/research-projects.ts; src/lib/names-terms.ts; src/lib/email-ingest.ts
severity: medium
reason: DW-314's whole argument is that a route gate is not enough because a direct library caller reaches the kernel with no route in front. This change applied that argument to `wikis.ts` only; `createResearchProject`, `createNamesTerm`/`updateNamesTerm`/`deleteNamesTerm` and `saveEmailIngestConfig` got HTTP gates alone.
status: open

### DW-395: `src/mcp.ts`'s batch ingest tool loops `ingestUrl` over up to MAX_BATCH_URLS URLs with no handle — the same one-action-N-documents shape DW-324 just closed for the HTTP batch route.
origin: spec-deferred a07d00ea301f
source_spec: `spec-dw-322-324-dictionary-guidance-and-request-cache.md`
location: src/mcp.ts:528
severity: medium
reason: `handleIngestBatch` (src/mcp.ts:526-532) calls `ingestUrl(url, {...})` sequentially inside a `for` loop, so every URL of one agent action resolves the Workspace Purpose and re-reads the dictionary from scratch. The remedy is now one line — add `guidanceCache: createGuidanceCache()` to that options literal — but DW-324 names `src/app/api/ingest/batch/route.ts` specifically and this spec's scope was held to the HTTP door, so the MCP door was deliberately not touched.
status: open

