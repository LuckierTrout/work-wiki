### DW-64: The configured deadline bounds a whole STREAM on `callLLMStream`, and a deadline that fires surfaces raw transport vocabulary.
origin: spec-deferred 0d779aa5cece
location: src/lib/llm.ts (callLLMStream, timeoutOption)
source_spec: `spec-1-9-settings-for-models-and-embeddings.md`
severity: medium
reason: `callLLMStream` is not retry-wrapped, so its single `AbortSignal.timeout` measures total stream duration rather than time-to-first-response: a 30s deadline set to catch hangs would truncate every answer that takes longer than 30s to finish. Separately, `AbortSignal.timeout` raises a `TimeoutError` whose message matches none of `RETRYABLE_MESSAGES`, so it propagates verbatim — "The operation was aborted due to timeout" is exactly the transport vocabulary this repo's copy rules exclude. Both need Chat's streaming semantics (Epic 3) to decide what a deadline means for a stream and which sentence the owner should see.
status: open
decision: 2026-08-21 Keep deadline, fix the copy — Leave the whole-stream deadline as the frozen decision has it and only map TimeoutError/AbortError to an owner-facing sentence in src/app/api/query/stream/route.ts, with a test pinning it.
decision: 2026-08-20 Keep deadline, fix the copy — Leave the whole-stream deadline as the frozen decision has it and only map TimeoutError/AbortError to an owner-facing sentence in src/app/api/query/stream/route.ts, with a test pinning it.

### DW-170: DW-17's stated reopening trigger, and three frozen story records, still quote the Story 1.4 AC phrase this change removed.
origin: spec-deferred 96e0e22d612c
source_spec: `spec-dw-30-wiki-lens-copy-and-invariant.md`
location: _bmad-output/implementation-artifacts/deferred-work.md:153
severity: medium
reason: `deferred-work.md:153` justifies DW-17 with "the per-Wiki Page partitioning that Story 1.4's 'the trees show that Wiki's files' implies", and the same phrase is quoted at `spec-1-2-create-a-wiki-from-a-scenario-template.md:71` and `spec-1-4-knowledge-tree-and-file-tree.md:25,132,310`. After this change that citation resolves to no live text in `epics.md`, so DW-17's rationale now rests on a phrase that no longer exists — which could either keep a migration alive on a dead citation or make it look spuriously resolved. The ledger is orchestrator-owned and the story specs are frozen records, so neither can be corrected from this story.
status: open

### DW-293: Every whole-file write now costs a real fsync, and nothing bounds that on the production paths that write in a loop.
origin: spec-deferred 76acb44f9ed6
source_spec: `spec-dw-161-164-storage-write-integrity.md`
location: src/lib/storage/filesystem.ts
severity: medium
reason: Measured under the full parallel suite: contributors 27ms -> 5091ms, lint 35ms -> 4854ms, query-history 102ms -> 24204ms. The same per-write cost is paid by `portable-archive.ts` on import (one write per archive entry), `backups.ts` on restore (one per asset), `embeddings.ts` on rebuild (each `upsertEmbedding` rewrites AND fsyncs the whole `.indexes/embeddings.json`) and by ingest. The cost is the durability guarantee working as specified, not a defect — but no benchmark, batching, or bound exists for those paths.
status: open
decision: 2026-08-20 Batch the loop paths — Keep fsync as the default for single writes, and give the loop paths a batched form: a bulk-write door that fsyncs once per batch (or a directory sync at the end) for portable-archive import, backup restore and ingest, plus an accumulate-then-flush shape for `upsertEmbedding` so an embeddings rebuild stops rewriting and syncing the whole index per vector. Add a benchmark that fails if any of those paths regresses past a recorded bound.

### DW-346: `POST /api/lint/fix`'s JSDoc is a sixth un-derived restatement of the fixable list and names only five of the ten types.
origin: spec-deferred 4043386addcd
source_spec: `spec-dw-229-246-hand-copied-list-parity.md`
location: src/app/api/lint/fix/route.ts:17
severity: medium
reason: `src/app/api/lint/fix/route.ts:17-30` lists `missing-crossref`, `orphan-page`, `stale-index`, `empty-page` and `contradiction` under "Supported issue types", omitting `broken-link`, `missing-concept-page`, `stale-page`, `unmigrated-page` and `supersedes-dangling` — the very type DW-229 was about. This story derived every executable copy of the list and left the one an integrator reads. It is a doc comment, so nothing observes it; the repo's own convention for pinning a prose inventory it cannot generate is `prose-inventory-parity.test.ts`.
status: open

### DW-362: The raw cap bounds one full-size document, so several mid-size supported documents are refused wholesale even though every per-document and per-count limit is respected.
origin: spec-deferred 95bfc309fad5
source_spec: `spec-dw-104-247-248-email-worker-caps-and-accounting.md`
location: workers/email-ingest/index.ts:59
severity: medium
reason: `MAX_EMAIL_ATTACHMENTS` is 10 and `MAX_DOCUMENT_SIZE` is 10 MB, so the advertised envelope is up to ten documents; ten 2 MB documents encode to roughly 27 MB and are bounced by `MAX_RAW_EMAIL_BYTES` (14.4 MB) with "larger than 13.7 MB". The per-message cap and the per-email attachment cap describe incompatible envelopes, which also makes the new over-cap acknowledgement line unreachable for anything but small files. Pre-existing and worse before this change (the cap was 10 MB); distinct from the aggregate-memory item above, which is about the forwarding copies rather than the gate.
status: open
decision: 2026-08-21 Derive an aggregate budget — Derive MAX_RAW_EMAIL_BYTES from a stated aggregate budget (up to MAX_EMAIL_ATTACHMENTS documents, or an explicit total) so the advertised attachment count is actually reachable, re-pin the parity test, and add a multi-document aggregate case.
decision: 2026-08-20 Derive an aggregate budget — Derive MAX_RAW_EMAIL_BYTES from a stated aggregate budget (up to MAX_EMAIL_ATTACHMENTS documents, or an explicit total) so the advertised attachment count is actually reachable, re-pin the parity test, and add a multi-document aggregate case.

### DW-375: `WikiSwitcher`'s create, rename and delete confirms stay live after an unconfirmed write, so a retry can seed a duplicate wiki or paint a 404 over a delete that landed.
origin: spec-deferred be4b261f912b
source_spec: `spec-dw-26-62-283-320-workbench-client-state-and-nav.md`
location: src/components/workbench/WikiSwitcher.tsx (create, rename, remove)
severity: medium
reason: The card holds its create door shut with `awaitingCreate` on the unconfirmed path; the switcher has no equivalent. `busy` is cleared in `finally`, the dialog stays open, and the confirm is pressable — over a POST that may have created the wiki (nothing enforces unique names) or a DELETE whose second attempt answers 404, which the switcher's own comment calls "a failure over an operation that in fact succeeded". Pre-existing: the retry window is the same one an aborted write has always left open; this change only renamed the message.
status: open

### DW-384: The sibling research routes (PATCH/DELETE `/api/research/[id]`, POST `/api/research/[id]/run`) still write and delete research-project records with no read-only gate.
origin: spec-deferred 4a4bbd173b0f
source_spec: `spec-dw-264-265-294-299-300-314-read-only-doors-and-affordances.md`
location: src/app/api/research/[id]/route.ts; src/app/api/research/[id]/run/route.ts
severity: medium
reason: DW-294 named only `POST /api/research`, which this change gated. The `[id]` handlers reach `updateResearchProject`/`deleteResearchProject`, reach no kernel writer, and contain no `isReadOnly` reference — so the feature refuses creates and accepts edits, deletes and runs.
status: open

### DW-393: An orphan page — on disk but absent from the page index — now makes its ingest-history row undeletable and fails the whole batch.
origin: spec-deferred a01843f3f763
source_spec: `spec-dw-121-230-269-270-authz-realm-parity-and-read-gates.md`
location: src/app/api/ingest/history/route.ts
severity: medium
reason: The DW-270 gate keys on `listReadableWikiPages`, which filters the page INDEX, not a per-page read. `src/lib/lint.ts:94`'s `checkOrphanPages` exists because index/disk drift is a real state here. A done job whose page is in that state used to delete the page and clear the job record; it now answers 404 for the entire request, clearing nothing else selected alongside it. This is exact parity with the pre-existing `ingestIds` preflight, which has always behaved this way, so DW-270 inherited the behaviour rather than inventing it.
status: open

