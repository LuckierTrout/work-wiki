# Deferred-work bundle: embeddings-drift-warning-rearm

bundle_name: embeddings-drift-warning-rearm
dw_ids: DW-332

## Intent

Re-arm the embedding-drift warning after a corpus rebuild so a corpus that drifts again is warned about again. Per the recorded decision (2026-08-21 "Re-arm drift only"): delete only the `drift:<active model>` key from `warnedMisconfigurations` on a successful read where `kept.length > 0`, leaving every other member of the Never clause intact. Today src/lib/embeddings.ts:789-795 only ever adds via `warnOnceAbout(`drift:${currentModel}`, ...)` and the Set is otherwise cleared solely by `_resetEmbeddingWarnings`. Cover rebuild-then-re-drift in the embeddings warning suite.

## Ledger entries (verbatim)

### DW-332: The `drift:<active model>` key is never re-armed, so a corpus that is rebuilt and then drifts again under the same active model is silent for the rest of the process.
origin: spec-deferred 694c7c190212
source_spec: `spec-dw-310-313-embedding-truth-and-warning-attribution.md`
location: src/lib/embeddings.ts (searchByVector, warnedMisconfigurations)
severity: medium
reason: `warnedMisconfigurations` is documented as never clearing, on the argument that "a restart (or a new isolate) already fixes" the case. That holds for the three env/binding misconfigurations it was written for, but not for drift: drift is fixed by REBUILDING THE CORPUS, which happens in the same process. `searchByVector` already holds the counter-signal that proves the drift is over — `kept.length > 0` — and could delete the key there. The intent said only "bring it under the same throttle", and the module's recorded trade-off argues the other way, so whether drift should be the one identity that re-arms is a decision neither contains.
status: open
decision: 2026-08-21 Re-arm drift only — Delete only the drift:<active model> key from warnedMisconfigurations on a successful read where kept.length > 0, leaving every other member of the Never clause intact, and cover rebuild-then-re-drift in the embeddings warning suite.
decision: 2026-08-20 Re-arm drift only — Delete only the drift:<active model> key from warnedMisconfigurations on a successful read where kept.length > 0, leaving every other member of the Never clause intact, and cover rebuild-then-re-drift in the embeddings warning suite.
