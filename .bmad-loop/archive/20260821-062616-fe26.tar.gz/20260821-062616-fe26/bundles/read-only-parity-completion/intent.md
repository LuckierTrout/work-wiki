# Deferred-work bundle: read-only-parity-completion

bundle_name: read-only-parity-completion
dw_ids: DW-384, DW-385, DW-386, DW-387

## Intent

Finish read-only mode so every writer refuses and every surface says so in one voice. Three research doors are ungated (src/app/api/research/[id]/route.ts PATCH/DELETE and [id]/run/route.ts POST) while the sibling create route refuses at src/app/api/research/route.ts:34. Three libraries write with no `assertWritable`: research-projects.ts:167, names-terms.ts:284/308/330, email-ingest.ts:97-113. NamesTermsSettings, EmailIngestSettings and KnowledgeStudio render no read-only affordance even though src/app/settings/page.tsx:283-284 mounts them beside siblings that take one, so the refusal is only met on submit. And three read-only sentences live outside `READ_ONLY_REFUSAL` (settings/page.tsx:153-154, api/settings/route.ts:130, api/settings/rebuild-embeddings/route.ts:16). Gate the routes and libraries, add the client affordances, and move the loose wordings into the registry with parity tests.

## Ledger entries (verbatim)

### DW-384: The sibling research routes (PATCH/DELETE `/api/research/[id]`, POST `/api/research/[id]/run`) still write and delete research-project records with no read-only gate.
origin: spec-deferred 4a4bbd173b0f
source_spec: `spec-dw-264-265-294-299-300-314-read-only-doors-and-affordances.md`
location: src/app/api/research/[id]/route.ts; src/app/api/research/[id]/run/route.ts
severity: medium
reason: DW-294 named only `POST /api/research`, which this change gated. The `[id]` handlers reach `updateResearchProject`/`deleteResearchProject`, reach no kernel writer, and contain no `isReadOnly` reference — so the feature refuses creates and accepts edits, deletes and runs.
status: open

### DW-385: The research, Names & Terms and email-ingest stores carry no `assertWritable`, so a CLI, MCP or agent-runtime caller still writes them on a read-only deployment.
origin: spec-deferred 192b376cbc62
source_spec: `spec-dw-264-265-294-299-300-314-read-only-doors-and-affordances.md`
location: src/lib/research-projects.ts; src/lib/names-terms.ts; src/lib/email-ingest.ts
severity: medium
reason: DW-314's whole argument is that a route gate is not enough because a direct library caller reaches the kernel with no route in front. This change applied that argument to `wikis.ts` only; `createResearchProject`, `createNamesTerm`/`updateNamesTerm`/`deleteNamesTerm` and `saveEmailIngestConfig` got HTTP gates alone.
status: open

### DW-386: Three surfaces now compose a write in front of a door this change taught to answer 403, with no read-only mirror — the DW-264/DW-265 shape, one bundle later.
origin: spec-deferred 56c9d9c9eb3d
source_spec: `spec-dw-264-265-294-299-300-314-read-only-doors-and-affordances.md`
location: src/components/NamesTermsSettings.tsx; src/components/EmailIngestSettings.tsx; src/components/KnowledgeStudio.tsx
severity: medium
reason: `NamesTermsSettings` and `EmailIngestSettings` render immediately below the `/settings` form that now refuses per control, and `KnowledgeStudio` posts to `/api/research`; all three submit and meet the new 403 afterwards. `READ_ONLY_REFUSAL.namesTerms` and `.emailSettings` consequently have no client counterpart and no parity-test entry.
status: open

### DW-387: `/settings` now states three different sentences for one deployment state, none of them owned by `READ_ONLY_REFUSAL` and none pinned by the parity suite.
origin: spec-deferred cba66956e0ae
source_spec: `spec-dw-264-265-294-299-300-314-read-only-doors-and-affordances.md`
location: src/app/settings/page.tsx:147; src/app/api/settings/route.ts:130; src/app/api/settings/rebuild-embeddings/route.ts
severity: medium
reason: The banner every refused control now points at reads "Read-only mode — This deployment has explicitly disabled settings changes."; `PUT /api/settings` answers "Settings are read-only in this deployment."; `POST /api/settings/rebuild-embeddings` answers a third wording. Only the banner is on screen, so the owner reads one sentence before pressing and another if anything reaches the route.
status: open
