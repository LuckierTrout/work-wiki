# Deferred-work bundle: settings-canvas-mount-preservation

bundle_name: settings-canvas-mount-preservation
dw_ids: DW-373

## Intent

Opening Settings should not unmount the Wiki behind it. src/components/workbench/Workbench.tsx:1089-1094 swaps `ModeCanvas` out for `SettingsCanvas` outright, and the code's own comment at :631-632 records the consequence. Keep the mode canvas mounted (hidden) while Settings is open so returning from Settings restores the canvas's state rather than remounting it, and pin that with a mounted test.

## Ledger entries (verbatim)

### DW-373: Opening the in-shell Settings surface still unmounts the whole mode canvas, so the Wiki subtree DW-26 keeps mounted across mode switches is destroyed — dialog, typed name and error — whenever Settings
origin: spec-deferred 125b109b6d09
source_spec: `spec-dw-26-62-283-320-workbench-client-state-and-nav.md`
location: src/components/workbench/Workbench.tsx (settingsOpen canvas swap)
severity: medium
reason: `Workbench.tsx` renders `settingsOpen ? <SettingsCanvas …/> : <ModeCanvas …>{children}</ModeCanvas>`, so `children` (`WikiWorkbench`) leaves the tree when the rail's Settings control — or, since this change, `g s` — opens the surface. Pre-existing: the rail control has behaved this way since Story 1.9, and DW-26 names `ModeCanvas` and mode switching only. Closing it means deciding how `SettingsCanvas` keeps owning discard-on-leave for its own draft while no longer being the thing that unmounts the canvas beside it.
status: open
