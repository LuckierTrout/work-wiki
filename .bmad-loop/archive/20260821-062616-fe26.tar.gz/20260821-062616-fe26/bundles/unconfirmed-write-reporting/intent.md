# Deferred-work bundle: unconfirmed-write-reporting

bundle_name: unconfirmed-write-reporting
dw_ids: DW-374, DW-375, DW-376

## Intent

Give the Workbench one honest story for a write whose outcome is unknown. `writeFailure` marks only `TimeoutError`/`AbortError` as unconfirmed (src/lib/workbench-request.ts:84-99), so `TypeError: Failed to fetch` and a 504 reach the owner verbatim as confirmed failures and no refresh fires. WikiSwitcher's create/rename/remove leave the dialog open and the confirm pressable after an unconfirmed write (src/components/workbench/WikiSwitcher.tsx:202-204, 231-233, 270-272), so a retry can paint failure over an operation that succeeded. SettingsCanvas and PreviewColumn arm their own deadlines and never import `writeFailure` at all (SettingsCanvas.tsx:177-179, 204; PreviewColumn.tsx:402-412). Widen the unconfirmed classification to network-level and gateway failures, latch the switcher's confirm while an unconfirmed write is outstanding, and route the two remaining client write paths through the shared classifier.

## Ledger entries (verbatim)

### DW-374: Only `TimeoutError`/`AbortError` are treated as unconfirmed, so a dropped connection or a 502/504 is reported as a known failure — with transport vocabulary — and no refresh runs.
origin: spec-deferred e6705ae0513e
source_spec: `spec-dw-26-62-283-320-workbench-client-state-and-nav.md`
location: src/lib/workbench-request.ts (writeFailure)
severity: medium
reason: `writeFailure` returns `unconfirmed: true` for the two abort names and otherwise prefers `cause.message`. A mid-write network drop arrives as `TypeError: Failed to fetch` (Safari: `Load failed`) and a gateway timeout as `send`'s `Request failed (504)`; in both the server may have applied the write, so the owner is told it failed over something unknown, and the screen is not reconciled. `Failed to fetch` also reaches the owner verbatim, which `workbench-settings.ts` already calls transport vocabulary no copy table contains. Pre-existing shape: `failureMessage` classified these the same way before this change.
status: open

### DW-375: `WikiSwitcher`'s create, rename and delete confirms stay live after an unconfirmed write, so a retry can seed a duplicate wiki or paint a 404 over a delete that landed.
origin: spec-deferred be4b261f912b
source_spec: `spec-dw-26-62-283-320-workbench-client-state-and-nav.md`
location: src/components/workbench/WikiSwitcher.tsx (create, rename, remove)
severity: medium
reason: The card holds its create door shut with `awaitingCreate` on the unconfirmed path; the switcher has no equivalent. `busy` is cleared in `finally`, the dialog stays open, and the confirm is pressable — over a POST that may have created the wiki (nothing enforces unique names) or a DELETE whose second attempt answers 404, which the switcher's own comment calls "a failure over an operation that in fact succeeded". Pre-existing: the retry window is the same one an aborted write has always left open; this change only renamed the message.
status: open

### DW-376: `SettingsCanvas.save` and `PreviewColumn` carry their own deadlines and still report a blown one as a flat failure, which is the claim DW-283 says the client cannot make.
origin: spec-deferred 5d49180cca3b
source_spec: `spec-dw-26-62-283-320-workbench-client-state-and-nav.md`
location: src/components/workbench/SettingsCanvas.tsx (save), src/components/workbench/PreviewColumn.tsx
severity: medium
reason: Both arm their own `AbortSignal` rather than using `send` (each needs the controller), so neither reaches `writeFailure`. `SettingsCanvas.save` resolves an abort to `SETTINGS_SAVE_FAILED_COPY` ("Settings couldn’t be saved.") over a PUT the server may have applied — on the surface this change just made keyboard-reachable through `g s`. Out of DW-283's stated scope, which names `workbench-request.ts` and the wiki writes.
status: open
