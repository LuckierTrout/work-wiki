# Deferred-work bundle: provider-selection-truthfulness

bundle_name: provider-selection-truthfulness
dw_ids: DW-368, DW-370

## Intent

Make provider selection tell the truth about what is actually usable. `detectEnvProvider` treats the mere presence of `OLLAMA_BASE_URL`/`OLLAMA_MODEL` as a working provider (src/lib/config.ts:777-779, mirrored at src/lib/embeddings.ts:217) while `getOllamaBaseUrl` (config.ts:343-350) refuses that same value when it is not an absolute http(s) URL and warns — so the resolved provider and the resolved endpoint disagree. Separately, StructuredKnowledgeSettings offers the `custom` provider (src/components/StructuredKnowledgeSettings.tsx:114-118 over src/lib/providers.ts:23) but renders only provider and model fields — no base URL and no API key — so picking it cannot be completed from that surface. Gate the env detection on a usable value rather than a present one, and either render the fields `custom` needs or stop offering it there, with tests for both (the component has no test file today).

## Ledger entries (verbatim)

### DW-368: The Extraction provider picker on the same flat /settings page also offers Custom and renders no base-URL or API-key field, so it stores a provider the runtime refuses to construct with no on-page poi
origin: spec-deferred ab8661d17322
source_spec: `spec-dw-61-327-329-legacy-settings-surface-parity.md`
location: src/components/StructuredKnowledgeSettings.tsx:84-99
severity: medium
reason: StructuredKnowledgeSettings.tsx populates its select from the same PROVIDER_INFO list that carries `custom`; the route accepts structuredKnowledgeProvider: "custom" and config.ts resolves it through getConfiguredModel, which throws "The Custom provider needs a base URL. Set it in Settings -> LLM Models." (src/lib/llm.ts:395-408) - the twin of the primary path's throw at :285-301 that DW-61 closed. Pre-existing: the DW-61 ledger entry and this bundle's intent both scope the fix to ProviderForm's picker, so the extraction picker was never in scope. There is no test file for StructuredKnowledgeSettings at all.
status: open

### DW-370: `detectEnvProvider()` and the embedding provider detection still select `ollama` from the mere presence of `OLLAMA_BASE_URL`, including a value `getOllamaBaseUrl` now refuses.
origin: spec-deferred 9a66b32844ef
source_spec: `spec-dw-71-326-272-settings-config-resolution-hardening.md`
location: src/lib/config.ts:739
severity: medium
reason: src/lib/config.ts:739-742 and src/lib/embeddings.ts:217 branch on the variable's presence, not on its usability. After DW-326 a typo'd `OLLAMA_BASE_URL=localhost:11434` both SELECTS the ollama provider and resolves to no endpoint, so generation and embed silently go to the SDK's own localhost default instead of failing against the address the owner typed. Pre-existing detection logic; the fall-through this bundle chose over a refusal is what makes the outcome silent. Closing it means either detecting through the validated accessor or writing down why detection deliberately answers a wider question.
status: open
