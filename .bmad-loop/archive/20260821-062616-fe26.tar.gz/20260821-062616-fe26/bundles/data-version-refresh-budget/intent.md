# Deferred-work bundle: data-version-refresh-budget

bundle_name: data-version-refresh-budget
dw_ids: DW-377

## Intent

Bound the data-version refresh retry by wall-clock rather than by poll count, and stop overlapping refreshes. `dataVersionRefreshPlan` counts attempts per poll with no timestamp on the state (src/lib/workbench-data-version.ts:144, 219-220), so the budget's meaning changes with the poll interval; and DataVersionWatcher fires `run()` from the interval, the visibility handler and the subscription with only an `AbortController` on the fetch — no guard against an in-flight `router.refresh()`. Give the plan a time-based window and the watcher a single-flight guard, with tests covering a fast-polling and a slow-polling budget and an overlapping trigger.

## Ledger entries (verbatim)

### DW-377: Retry attempts are counted per qualifying poll rather than per settled re-render, so a nudge or visibility burst — or a merely slow refresh — can spend the whole budget before any new baseline has had
origin: spec-deferred eb490a039820
source_spec: `spec-dw-48-data-version-refresh-retry.md`
location: src/components/workbench/DataVersionWatcher.tsx (run), src/lib/workbench-data-version.ts (DATA_VERSION_REFRESH_ATTEMPTS)
severity: medium
reason: `run()` has three triggers: the `DATA_VERSION_POLL_MS` interval, `visibilitychange` -> visible, and the `requestDataVersionCheck()` save nudge (`PreviewColumn.tsx`). Every qualifying poll from any of them spends an attempt, so three alt-tabs or three saves that all still answer the same version drive `attempts` from 0 to `DATA_VERSION_REFRESH_ATTEMPTS` in milliseconds and re-strand that version — the DW-48 symptom, now probabilistic rather than certain. The same shape covers an in-flight `router.refresh()` still rendering when the next tick fires: a merely slow re-render reads as "did not catch up" and burns an attempt. A wall-clock window (which DW-48's own wording offered as an alternative to a count) or an in-flight guard would close it; both are refresh-policy decisions beyond the bounded-count reading this story implemented, and the count reading is strictly better than the single-shot stamp it replaced in every case.
status: open
