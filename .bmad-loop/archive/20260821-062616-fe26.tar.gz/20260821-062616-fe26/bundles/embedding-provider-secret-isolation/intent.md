# Deferred-work bundle: embedding-provider-secret-isolation

bundle_name: embedding-provider-secret-isolation
dw_ids: DW-69, DW-72

## Intent

Stop one vendor's embedding secret and endpoint from being handed to another vendor when the embedding provider changes. Per the recorded decisions (2026-08-21, DW-69 "Clear the key on switch" and DW-72 "Clear the base URL on switch"): drop the stored `embeddingApiKey` and its `has*` presence flag, and clear the stored `embeddingBaseUrl`, whenever `embeddingProvider` changes — so a switch never reuses another vendor's credential or endpoint and the owner re-enters both for the new vendor. No stored-shape change. Today src/lib/config.ts:1396-1399 sets provider and key independently, src/lib/workbench-settings.ts:1518 carries the stored base URL across a provider change, and src/lib/embeddings.ts:411-425 spreads the same `baseUrlOption` into both `createOpenAI` and `createGoogleGenerativeAI`. Pin the clear-on-switch behaviour for both fields over the settings route and the workbench settings patch path.

## Ledger entries (verbatim)

### DW-69: One `embeddingApiKey` is shared by both keyed embedding vendors, so switching provider silently reuses the other vendor's key.
origin: spec-deferred bddb90da84c0
location: src/lib/embeddings.ts:139, src/lib/config.ts (getWorkbenchSettings)
source_spec: `spec-1-9-settings-for-models-and-embeddings.md`
severity: medium
reason: `embeddingApiKeyFor` reads the same stored value for `openai` and `google`, and `settingsSaveBody` omits an untouched secret — so an owner who stored an OpenAI key and then picks Google sends that key to Google while the hint still reads "A key is stored." Keying the field per provider (or labelling which vendor the stored key belongs to) is a store-shape decision this story's acceptance does not settle; the vector gate's env leg was made provider-aware in this pass, but the STORED key deliberately stayed vendor-agnostic so a provider changed in the draft can still answer the gate before it is saved.
status: open
decision: 2026-08-21 Clear the key on switch — Drop the stored embedding key and its has* flag whenever the embedding provider changes, so a switch never reuses another vendor's secret; no stored shape change, and the owner re-enters the key for the new vendor.
decision: 2026-08-20 Clear the key on switch — Drop the stored embedding key and its has* flag whenever the embedding provider changes, so a switch never reuses another vendor's secret; no stored shape change, and the owner re-enters the key for the new vendor.

### DW-72: One stored `embeddingBaseUrl` is handed to whichever embedding provider is active, so an endpoint entered for OpenAI is sent to Google after a switch.
origin: spec-deferred 1ed1cc09bf7d
location: src/lib/embeddings.ts:228-238 (_createEmbeddingModel)
source_spec: `spec-1-9-settings-for-models-and-embeddings.md`
severity: medium
reason: `_createEmbeddingModel` reads `loadConfigSync().embeddingBaseUrl` and applies it to the `openai` and `google` branches alike, with nothing tying the value to the provider it was typed for. This is the endpoint twin of the already-recorded vendor-agnostic `embeddingApiKey`, and it has the same resolution: keying the field per provider is a store-shape decision this story's acceptance does not settle. Nothing breaks today — the pair is usually changed together — but the silent reuse is real.
status: open
decision: 2026-08-21 Clear the base URL on switch — Clear the stored embeddingBaseUrl whenever the embedding provider changes, so an endpoint typed for one vendor is never sent to another; no stored shape change.
decision: 2026-08-20 Clear the base URL on switch — Clear the stored embeddingBaseUrl whenever the embedding provider changes, so an endpoint typed for one vendor is never sent to another; no stored shape change.
